export interface MessageInterface {
    id: string;
    text: string;
    pending: boolean;
}