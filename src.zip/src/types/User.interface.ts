export interface UserInterface {
    id: number
    name: string
    email: string
    username: string
}